# BharatFinTrack

A Python package designed to simplify the process of downloading and analyzing financial data, including indices, stocks, and mutual funds, from India, that is, Bharat.


### Installation

```
    pip install BharatFinTrack
```


### License

`BharatFinTrack` is released under the MIT License.