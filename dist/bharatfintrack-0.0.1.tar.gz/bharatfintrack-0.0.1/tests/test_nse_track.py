import pytest
import os
import sys

package_path = os.path.abspath('..')
if package_path in sys.path:
    pass
else:
    sys.path.append(package_path)
    
import BharatFinTrack

@pytest.fixture(scope='module')
def class_instance():
    
    return BharatFinTrack.NSETrack()
    
    
def test_indices_category(class_instance):
    
    output = class_instance.indices_category
    
    assert output == ['broad', 'sectoral', 'thematic', 'strategy']
    
    
# # def test_sub():

# #     assert 2 - 2 == 0